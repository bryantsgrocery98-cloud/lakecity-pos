// Launcher: starts the register and restarts it after an update.
// Exit code 75 from the server means "an update was installed, start me again".
// With POS_HIDDEN=1 (the desktop icon and auto-start), output goes to data/logs instead of a console window.
import { spawn, spawnSync } from 'node:child_process';
import fs from 'node:fs';
import http from 'node:http';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.dirname(fileURLToPath(import.meta.url));
const isWin = process.platform === 'win32';
const npx = isWin ? 'npx.cmd' : 'npx';
const npm = isWin ? 'npm.cmd' : 'npm';
const port = Number(process.env.PORT ?? 3000);
const url = `http://localhost:${port}`;
let opened = false;

const [major, minor] = process.versions.node.split('.').map(Number);
if (major < 22 || (major === 22 && minor < 13)) {
  console.log(`This POS needs Node.js 22.13 or newer (you have ${process.versions.node}). Install the LTS from https://nodejs.org and start again.`);
  process.exit(1);
}

// ----- logging -----
const logDir = path.join(root, 'data', 'logs');
fs.mkdirSync(logDir, { recursive: true });
const logFile = path.join(logDir, 'pos.log');
try { if (fs.existsSync(logFile) && fs.statSync(logFile).size > 5_000_000) fs.renameSync(logFile, path.join(logDir, 'pos.old.log')); } catch { /* fine */ }
const logStream = fs.createWriteStream(logFile, { flags: 'a' });
const log = (msg) => { const line = `${new Date().toISOString()} ${msg}`; logStream.write(line + '\n'); if (!process.env.POS_HIDDEN) console.log(msg); };

// ----- browser -----
function findBrowser() {
  if (!isWin) return null;
  const candidates = [
    'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe',
    'C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe',
    'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
    'C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe',
    path.join(process.env.LOCALAPPDATA ?? '', 'Google\\Chrome\\Application\\chrome.exe'),
  ];
  return candidates.find((p) => p && fs.existsSync(p)) ?? null;
}

// Opens the register screen through the register itself: it knows whether one is already showing and, if so,
// brings that one to the front instead of opening a second window.
function openBrowser() {
  if (opened || process.env.POS_NO_BROWSER) return;
  opened = true;
  const body = JSON.stringify({ windowed: !!process.env.POS_WINDOWED });
  const req = http.request(`${url}/api/register/open`, { method: 'POST', headers: { 'content-type': 'application/json', 'content-length': Buffer.byteLength(body) }, timeout: 15000 }, (res) => {
    let out = ''; res.on('data', (d) => { out += d; }); res.on('end', () => { try { log(`Register screen: ${JSON.parse(out).message}`); } catch { /* fine */ } });
  });
  req.on('error', (e) => { log(`Could not open the register screen: ${e.message}`); opened = false; });
  req.on('timeout', () => req.destroy());
  req.end(body);
}

// Ask the register to put the customer screen on the second monitor (it does nothing if that window is already open).
function openCustomerScreen() {
  if (process.env.POS_NO_BROWSER) return;
  const req = http.request(`${url}/api/display/open`, { method: 'POST', headers: { 'content-type': 'application/json' }, timeout: 15000 }, (res) => {
    let body = ''; res.on('data', (d) => { body += d; }); res.on('end', () => { try { log(`Customer screen: ${JSON.parse(body).message}`); } catch { /* fine */ } });
  });
  req.on('error', () => {}); req.on('timeout', () => req.destroy());
  req.end('{}');
}

function alreadyRunning() {
  return new Promise((resolve) => {
    const req = http.get(`${url}/api/version`, { timeout: 1500 }, (res) => { res.resume(); resolve(res.statusCode === 200); });
    req.on('error', () => resolve(false));
    req.on('timeout', () => { req.destroy(); resolve(false); });
  });
}

function applyPending() {
  const p = path.join(root, 'updates', 'pending.json');
  if (!fs.existsSync(p)) return;
  let info = {};
  try { info = JSON.parse(fs.readFileSync(p, 'utf8')); } catch { /* ignore */ }
  fs.rmSync(p, { force: true });
  if (info.npmInstall) {
    log(`Finishing update to version ${info.version}: installing parts…`);
    const r = spawnSync(npm, ['install', '--omit=dev', '--no-audit', '--no-fund'], { cwd: root, stdio: process.env.POS_HIDDEN ? 'ignore' : 'inherit', shell: isWin, windowsHide: true });
    if (r.status !== 0) log('npm install had a problem. The register will still try to start.');
  }
}

function run() {
  applyPending();
  const child = spawn(npx, ['tsx', 'src/server/index.ts'], { cwd: root, stdio: ['ignore', 'pipe', 'pipe'], shell: isWin, windowsHide: true, env: { ...process.env, POS_LAUNCHER: '1' } });
  child.stdout.on('data', (d) => log(String(d).trimEnd()));
  child.stderr.on('data', (d) => { const s = String(d).trimEnd(); if (!/ExperimentalWarning|trace-warnings|DeprecationWarning|trace-deprecation/.test(s)) log(s); });
  child.on('exit', (code) => {
    if (code === 75) { log('Restarting after update…'); setTimeout(run, 500); }
    else if (code !== 0 && code !== null) { log(`Register stopped unexpectedly (${code}); restarting in 5s.`); setTimeout(run, 5000); }
    else { log(`Register stopped (${code ?? 'signal'}).`); process.exit(code ?? 0); }
  });
  // Open the screens once the register answers.
  let tries = 0;
  const whenUp = () => { alreadyRunning().then((up) => { if (up) { openBrowser(); setTimeout(openCustomerScreen, 3000); } else if (tries++ < 60) setTimeout(whenUp, 1000); }); };
  setTimeout(whenUp, 1500);
}

alreadyRunning().then((running) => {
  if (running) { log('Register is already running; opening the screens.'); openBrowser(); openCustomerScreen(); setTimeout(() => process.exit(0), 4000); }
  else run();
});
